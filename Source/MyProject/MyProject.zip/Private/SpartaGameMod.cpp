// Fill out your copyright notice in the Description page of Project Settings.


#include "SpartaGameMod.h"
#include "SpartaCharacter.h"
#include "SpartaPlayerController.h"

ASpartaGameMod::ASpartaGameMod()
{
	DefaultPawnClass = ASpartaCharacter::StaticClass();
	PlayerControllerClass = ASpartaPlayerController::StaticClass();
}